#pragma once
// RNOH PATCH
// Remove conditional inclusion for ANDROID
#include "Logger.h"
#include "LoggerInterface.h"
#include "SpeedChecker.h"
